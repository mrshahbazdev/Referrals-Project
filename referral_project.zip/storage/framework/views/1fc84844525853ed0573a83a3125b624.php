<!-- Sidebar Header -->
<div class="sidebar-header">
    <i class="ph-bold ph-shield-check icon"></i>
    <h2>Admin Panel</h2>
</div>

<!-- Sidebar Navigation -->
<nav class="sidebar-nav">
    <ul>
        <li><a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>"><i class="ph ph-gauge"></i> Dashboard</a></li>
        <li><a href="<?php echo e(route('admin.users.index')); ?>" class="<?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>"><i class="ph ph-users"></i> User Management</a></li>
        <li><a href="<?php echo e(route('admin.levels.index')); ?>" class="<?php echo e(request()->routeIs('admin.levels.*') ? 'active' : ''); ?>"><i class="ph ph-stairs"></i> Level Management</a></li>
        <li><a href="<?php echo e(route('admin.tasks.index')); ?>" class="<?php echo e(request()->routeIs('admin.tasks.*') ? 'active' : ''); ?>"><i class="ph ph-list-checks"></i> Task Management</a></li>
        <li><a href="<?php echo e(route('admin.kyc.index')); ?>" class="<?php echo e(request()->routeIs('admin.kyc.*') ? 'active' : ''); ?>"><i class="ph ph-identification-card"></i> KYC Submissions</a></li>
        <li><a href="<?php echo e(route('admin.investments.index')); ?>" class="<?php echo e(request()->routeIs('admin.investments.*') ? 'active' : ''); ?>"><i class="ph ph-chart-line-up"></i> Investment Requests</a></li>
        <li><a href="<?php echo e(route('admin.withdrawals.index')); ?>" class="<?php echo e(request()->routeIs('admin.withdrawals.*') ? 'active' : ''); ?>"><i class="ph ph-arrow-circle-down"></i> Withdrawal Requests</a></li>
        <li><a href="<?php echo e(route('admin.deposit-methods.index')); ?>" class="<?php echo e(request()->routeIs('admin.deposit-methods.*') ? 'active' : ''); ?>"><i class="ph ph-bank"></i> Deposit Methods</a></li>
        <li><a href="<?php echo e(route('admin.announcements.index')); ?>" class="<?php echo e(request()->routeIs('admin.announcements.*') ? 'active' : ''); ?>"><i class="ph ph-megaphone"></i> Announcements</a></li>
        <li><a href="<?php echo e(route('admin.admins.index')); ?>" class="<?php echo e(request()->routeIs('admin.admins.*') ? 'active' : ''); ?>"><i class="ph ph-user-gear"></i> Admin Management</a></li>
        <li><a href="<?php echo e(route('admin.activity_logs.index')); ?>" class="<?php echo e(request()->routeIs('admin.activity_logs.*') ? 'active' : ''); ?>"><i class="ph ph-list-dashes"></i> Admin Log</a></li>
        <li><a href="<?php echo e(route('admin.user_activity.index')); ?>" class="<?php echo e(request()->routeIs('admin.user_activity.*') ? 'active' : ''); ?>"><i class="ph ph-user-list"></i> User Log</a></li>
        
        <li><a href="<?php echo e(route('admin.settings.index')); ?>" class="<?php echo e(request()->routeIs('admin.settings.*') ? 'active' : ''); ?>"><i class="ph ph-gear"></i> Settings</a></li>
    </ul>
</nav>

<!-- Logout Button -->
<div class="logout-section">
    <form method="POST" action="<?php echo e(route('admin.logout')); ?>" class="logout-form">
        <?php echo csrf_field(); ?>
        <button type="submit">
            <a class="logout-link"><i class="ph ph-sign-out"></i> Logout</a>
        </button>
    </form>
</div>
<?php /**PATH E:\Projects\cod app\new\tasks website for earning\referral_project\resources\views/admin/layouts/partials/sidebar.blade.php ENDPATH**/ ?>