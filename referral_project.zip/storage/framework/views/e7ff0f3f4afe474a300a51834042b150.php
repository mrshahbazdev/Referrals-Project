<?php $__env->startSection('title', 'Download App'); ?>
<?php $__env->startSection('content'); ?>
    <div class="text-center space-y-4">
        <i class="ph-bold ph-download-simple text-5xl text-yellow-400"></i>
        <h2 class="text-2xl font-bold">Install CodeShack App</h2>
        <p class="text-gray-400">For a better experience, install our app on your device. Click the "Install" button in your browser's address bar or find the "Add to Home Screen" option in your browser menu.</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Projects\cod app\new\tasks website for earning\referral_project\resources\views/pages/app-download.blade.php ENDPATH**/ ?>