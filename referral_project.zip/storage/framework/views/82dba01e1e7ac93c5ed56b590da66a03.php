<?php $__env->startSection('title', 'Terms and Conditions'); ?>

<?php $__env->startSection('content'); ?>
    <div class="space-y-6">
        <div class="text-center">
            <i class="ph-bold ph-file-text text-5xl text-yellow-400"></i>
            <h2 class="text-2xl font-bold text-white mt-4">Terms and Conditions</h2>
        </div>

        <div class="bg-[#1E1F2B] p-4 rounded-lg space-y-4 text-gray-300 text-sm prose">
            <?php echo $settings['terms_and_conditions'] ?? 'No terms and conditions have been set yet.'; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Projects\cod app\new\tasks website for earning\referral_project\resources\views/pages/terms.blade.php ENDPATH**/ ?>