<?php $__env->startSection('title', 'Transaction Records'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .tab.active {
        background-color: #facc15; /* yellow-400 */
        color: #10111A;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="space-y-4">
        <h2 class="text-xl font-bold text-center">Records</h2>

        <!-- Filter Tabs -->
        <div id="filter-tabs" class="flex flex-wrap gap-2 bg-[#1E1F2B] p-2 rounded-lg">
            <a href="<?php echo e(route('transactions.index')); ?>" class="tab <?php echo e(!$selectedType ? 'active' : ''); ?> flex-grow text-center w-auto py-2 text-sm font-bold rounded-full transition-colors <?php echo e(!$selectedType ? '' : 'text-gray-400'); ?>">All</a>
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('transactions.index', ['type' => $type])); ?>" class="tab <?php echo e($selectedType == $type ? 'active' : ''); ?> flex-grow text-center w-auto py-2 text-sm font-bold rounded-full transition-colors <?php echo e($selectedType == $type ? '' : 'text-gray-400'); ?> capitalize"><?php echo e(str_replace('_', ' ', $type)); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Transaction List -->
        <div id="transaction-list" class="space-y-3">
            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="transaction-item bg-[#1E1F2B] p-3 rounded-lg flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <div class="p-2 rounded-full
                            <?php if($transaction->amount > 0 && $transaction->type == 'commission'): ?> bg-purple-500/10
                            <?php elseif($transaction->amount > 0): ?> bg-green-500/10
                            <?php else: ?> bg-red-500/10 <?php endif; ?>">

                            <?php if($transaction->type == 'commission'): ?>
                                <i class="ph ph-users-three text-xl text-purple-400"></i>
                            <?php elseif($transaction->amount > 0): ?>
                                <i class="ph ph-arrow-down text-xl text-green-400"></i>
                            <?php else: ?>
                                <i class="ph ph-arrow-up text-xl text-red-400"></i>
                            <?php endif; ?>
                        </div>
                        <div>
                            <p class="font-semibold capitalize"><?php echo e(str_replace('_', ' ', $transaction->type)); ?></p>
                            <p class="text-xs text-gray-500"><?php echo e($transaction->created_at->format('d M, Y h:i A')); ?></p>
                        </div>
                    </div>
                    <div class="text-right">
                        <p class="font-bold <?php echo e($transaction->amount > 0 ? 'text-green-400' : 'text-red-400'); ?>">
                            <?php echo e($transaction->amount > 0 ? '+' : ''); ?> $<?php echo e(number_format($transaction->amount, 2)); ?>

                        </p>
                        <p class="text-xs text-gray-500">Completed</p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center text-gray-500 py-10">
                    <i class="ph ph-files text-4xl"></i>
                    <p class="mt-2">No records found for this filter.</p>
                </div>
            <?php endif; ?>
        </div>

        <div class="pagination-links">
            <?php echo e($transactions->appends(request()->query())->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Projects\cod app\new\tasks website for earning\referral_project\resources\views/transactions/index.blade.php ENDPATH**/ ?>