<!-- Menu Header -->
<div class="flex justify-between items-center mb-10">
    <div class="flex items-center gap-3">
        <div class="bg-yellow-400 p-2 rounded-full">
            <i class="ph-fill ph-user text-black text-xl"></i>
        </div>
        <span class="font-bold text-lg text-white"><?php echo e($settings['site_name'] ?? config('app.name')); ?></span>
    </div>
    <i id="close-menu-button" class="ph ph-x text-2xl cursor-pointer p-1 rounded-full hover:bg-gray-800"></i>
</div>


<!-- Menu Links -->
<div class="flex flex-col h-full">
    <p class="text-sm text-gray-500 uppercase tracking-wider mb-4">Menu</p>
    <nav class="flex flex-col space-y-2">
        <a href="<?php echo e(route('home')); ?>" class="flex items-center justify-between p-3 rounded-lg hover:bg-[#1E1F2B] <?php echo e(request()->routeIs('home') ? 'bg-[#1E1F2B]' : ''); ?>">
            <div class="flex items-center gap-4"><i class="ph ph-house text-xl text-yellow-400"></i><span class="text-white">Home</span></div>
            <i class="ph ph-caret-right text-gray-500"></i>
        </a>
        <a href="<?php echo e(route('team.index')); ?>" class="flex items-center justify-between p-3 rounded-lg hover:bg-[#1E1F2B] <?php echo e(request()->routeIs('team.index') ? 'bg-[#1E1F2B]' : ''); ?>">
            <div class="flex items-center gap-4"><i class="ph ph-users-three text-xl text-yellow-400"></i><span class="text-white">My Team</span></div>
            <i class="ph ph-caret-right text-gray-500"></i>
        </a>
        <a href="<?php echo e(route('levels.index')); ?>" class="flex items-center justify-between p-3 rounded-lg hover:bg-[#1E1F2B] <?php echo e(request()->routeIs('levels.index') ? 'bg-[#1E1F2B]' : ''); ?>">
            <div class="flex items-center gap-4"><i class="ph ph-stairs text-xl text-yellow-400"></i><span class="text-white">Upgrade Level</span></div>
            <i class="ph ph-caret-right text-gray-500"></i>
        </a>
    </nav>
    <p class="text-sm text-gray-500 uppercase tracking-wider mt-10 mb-4">Others</p>
    <nav class="flex flex-col space-y-2">
        <a href="<?php echo e(route('profile.edit')); ?>" class="flex items-center justify-between p-3 rounded-lg hover:bg-[#1E1F2B] <?php echo e(request()->routeIs('profile.edit') ? 'bg-[#1E1F2B]' : ''); ?>">
            <div class="flex items-center gap-4"><i class="ph ph-gear text-xl text-yellow-400"></i><span class="text-white">Settings</span></div>
            <i class="ph ph-caret-right text-gray-500"></i>
        </a>
       <a href="<?php echo e(route('app.download')); ?>" class="flex items-center justify-between p-3 rounded-lg hover:bg-[#1E1F2B] <?php echo e(request()->routeIs('app.download') ? 'bg-[#1E1F2B]' : ''); ?>">
            <div class="flex items-center gap-4"><i class="ph ph-download-simple text-xl text-yellow-400"></i><span class="text-white">App Download</span></div>
            <i class="ph ph-caret-right text-gray-500"></i>
        </a>
        <a href="<?php echo e(route('terms')); ?>" class="flex items-center justify-between p-4">
            <div class="flex items-center gap-4"><i class="ph ph-file-text text-2xl text-gray-400"></i><span>Terms & Conditions</span></div>
            <i class="ph ph-caret-right text-gray-500"></i>
        </a>
        <a href="<?php echo e(route('about')); ?>" class="flex items-center justify-between p-3 rounded-lg hover:bg-[#1E1F2B] <?php echo e(request()->routeIs('about') ? 'bg-[#1E1F2B]' : ''); ?>">
            <div class="flex items-center gap-4"><i class="ph ph-info text-xl text-yellow-400"></i><span class="text-white">About Us</span></div>
            <i class="ph ph-caret-right text-gray-500"></i>
        </a>
    </nav>
    <nav class="flex flex-col space-y-2">
      <div class="mt-auto">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="w-full">
                <span class="flex items-center justify-between p-3 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 w-full">
                    <div class="flex items-center gap-4">
                        <i class="ph ph-sign-out text-xl"></i>
                        <span class="font-semibold">Logout</span>
                    </div>
                </span>
            </button>
        </form>
    </div>
    </nav>
</div>
</div>
<?php /**PATH E:\Projects\cod app\new\tasks website for earning\referral_project\resources\views/layouts/partials/frontend-sidebar.blade.php ENDPATH**/ ?>