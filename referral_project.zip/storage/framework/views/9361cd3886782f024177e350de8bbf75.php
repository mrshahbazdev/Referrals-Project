<?php $__env->startSection('title', 'User Management'); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        /* Aap apne dashboard se styles copy kar sakte hain */
        body { font-family: sans-serif; background-color: #111827; color: #f1f5f9; }
        .dashboard-layout { display: flex; min-height: 100vh; }
        .sidebar { width: 260px; background-color: #1E293B; padding: 1.5rem; }
        .main-content { flex-grow: 1; padding: 2rem; }
        .main-header h1 { font-size: 1.75rem; margin-bottom: 2rem; }
        .table-container { background-color: #1E293B; border-radius: 12px; overflow: hidden; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 1rem; text-align: left; border-bottom: 1px solid #334155; }
        th { background-color: #334155; }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
            <header class="main-header"><h1>User Activity Log</h1></header>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Action</th>
                            <th>Description</th>
                            <th>Timestamp</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($log->user->username ?? 'N/A'); ?></td>
                                <td><?php echo e($log->action); ?></td>
                                <td><?php echo e($log->description); ?></td>
                                <td><?php echo e($log->created_at->format('d M, Y h:i A')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="4" style="text-align: center; padding: 2rem;">No user activities logged yet.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="pagination-links"><?php echo e($logs->links()); ?></div>
        </main>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Projects\cod app\new\tasks website for earning\referral_project\resources\views/admin/user_logs/index.blade.php ENDPATH**/ ?>