<?php $__env->startSection('title', 'Log Management'); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        :root { --bg-dark: #111827; --sidebar-bg: #1E293B; --card-bg: #1E293B; --text-primary: #f1f5f9; --text-secondary: #94a3b8; --accent-color: #facc15; --border-color: #334155; }
        body { font-family: sans-serif; background-color: var(--bg-dark); color: var(--text-primary); }
        .dashboard-layout { display: flex; min-height: 100vh; }
        .sidebar { width: 260px; background-color: var(--sidebar-bg); padding: 1.5rem; /* Add full sidebar styles */ }
        .main-content { flex-grow: 1; padding: 2rem; }
        .main-header h1 { font-size: 1.75rem; margin-bottom: 1rem; }
        .log-tabs { display: flex; gap: 0.5rem; border-bottom: 1px solid var(--border-color); margin-bottom: 2rem; }
        .log-tabs a { padding: 0.75rem 1.5rem; text-decoration: none; color: var(--text-secondary); border-bottom: 2px solid transparent; }
        .log-tabs a.active { color: var(--accent-color); border-bottom-color: var(--accent-color); font-weight: 600; }
        .table-container { background-color: var(--card-bg); border-radius: 12px; border: 1px solid var(--border-color); overflow: hidden; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 1rem; text-align: left; border-bottom: 1px solid var(--border-color); }
        th { background-color: #334155; }
        .pagination-links { margin-top: 1.5rem; }
        /* New Pagination Styles */
        .pagination-links nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .pagination-links a, .pagination-links span {
            padding: 0.6rem 1.2rem;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.875rem;
        }
        .pagination-links a {
            background-color: var(--accent-color);
            color: var(--bg-dark);
            transition: background-color 0.2s;
        }
        .pagination-links a:hover {
            background-color: #fde047; /* Lighter yellow */
        }
        /* This styles the disabled "Previous" or "Next" button */
        .pagination-links span {
            background-color: var(--border-color);
            color: var(--text-secondary);
            cursor: not-allowed;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
            <header class="main-header"><h1>Admin Activity Log</h1></header>

            <div class="log-tabs">
                <?php $__currentLoopData = $logTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('admin.activity_logs.index', ['type' => $type])); ?>" class="<?php echo e($selectedType == $type ? 'active' : ''); ?>">
                        <?php echo e($type); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Admin</th>
                            <th>Action</th>
                            <th>Description</th>
                            <th>Timestamp</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($log->admin->username ?? 'N/A'); ?></td>
                                <td><?php echo e($log->action); ?></td>
                                <td><?php echo e($log->description); ?></td>
                                <td><?php echo e($log->created_at->format('d M, Y h:i A')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="4" style="text-align: center; padding: 2rem;">No activities logged for this category.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="pagination-links"><?php echo e($logs->links()); ?></div>
        </main>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Projects\cod app\new\tasks website for earning\referral_project\resources\views/admin/logs/index.blade.php ENDPATH**/ ?>