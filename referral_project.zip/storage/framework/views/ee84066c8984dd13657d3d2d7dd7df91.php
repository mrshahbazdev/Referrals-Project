<?php $__env->startSection('title', 'Upgrade Level'); ?>

<?php $__env->startSection('content'); ?>
    <div class="space-y-6">
        <div class="text-center">
            <i class="ph-bold ph-rocket-launch text-5xl text-yellow-400"></i>
            <h2 class="text-2xl font-bold text-white mt-4">Upgrade Your Level</h2>
            <p class="text-gray-400">Unlock more benefits and increase your daily earnings.</p>
        </div>

        <?php if(session('success')): ?>
            <div class="bg-green-500/10 text-green-300 p-4 rounded-lg text-center"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="bg-red-500/10 text-red-300 p-4 rounded-lg text-center">
                <?php echo e(session('error')); ?>

                <a href="<?php echo e(route('deposit.create')); ?>" class="font-bold underline">Click here to deposit.</a>
            </div>
        <?php endif; ?>

        <div class="space-y-4">
            <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-[#1E1F2B] p-4 rounded-lg border-2 <?php echo e($user->level_id == $level->id ? 'border-yellow-400' : 'border-transparent'); ?>">
                    <div class="flex items-center gap-4">
                        <?php if($level->icon_url): ?>
                            <img src="<?php echo e(asset('storage/' . $level->icon_url)); ?>" alt="<?php echo e($level->name); ?>" class="w-16 h-16 rounded-full object-cover">
                        <?php endif; ?>
                        <div class="flex-grow">
                            <h3 class="font-bold text-lg text-white"><?php echo e($level->name); ?></h3>
                            <p class="text-sm text-gray-400">Daily Tasks: <span class="font-semibold"><?php echo e($level->daily_task_limit); ?></span></p>
                            <p class="text-sm text-gray-400">Upgrade Cost: <span class="font-semibold">$<?php echo e(number_format($level->upgrade_cost, 2)); ?></span></p>
                        </div>
                    </div>
                    <div class="mt-4">
                        <?php if($user->level_id > $level->id): ?>
                            <button class="w-full bg-gray-600 text-gray-400 font-bold py-2 rounded-lg cursor-not-allowed">Unlocked</button>
                        <?php elseif($user->level_id == $level->id): ?>
                            <button class="w-full bg-green-600 text-white font-bold py-2 rounded-lg cursor-not-allowed">Current Plan</button>
                        <?php else: ?>
                            <form action="<?php echo e(route('levels.upgrade', $level)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="w-full bg-yellow-400 text-black font-bold py-2 rounded-lg hover:bg-yellow-500 transition-colors">Upgrade</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Projects\cod app\new\tasks website for earning\referral_project\resources\views/levels/index.blade.php ENDPATH**/ ?>