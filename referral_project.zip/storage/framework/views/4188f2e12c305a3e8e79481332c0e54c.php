<?php $__env->startSection('title', 'About Us'); ?>

<?php $__env->startSection('content'); ?>
    <div class="space-y-6">
        <div class="flex flex-col items-center text-center">
            <div class="bg-[#1E1F2B] p-4 rounded-full">
               <i class="ph-bold ph-info text-5xl text-yellow-400"></i>
            </div>
            <h2 class="text-2xl font-bold mt-4">About CODESHACK</h2>
            <p class="text-sm text-gray-400 mt-2">Your trusted partner in the world of cryptocurrency and quantitative trading.</p>
        </div>

        <div class="bg-[#1E1F2B] p-4 rounded-lg space-y-4">
            <div>
                <h3 class="font-semibold text-lg text-yellow-400">Our Mission</h3>
                <p class="text-sm text-gray-300 mt-1">
                    To provide a secure, reliable, and user-friendly platform for everyone to access the financial opportunities offered by digital assets. We believe in empowering our users with advanced tools and transparent information.
                </p>
            </div>
             <div>
                <h3 class="font-semibold text-lg text-yellow-400">Who We Are</h3>
                <p class="text-sm text-gray-300 mt-1">
                    CODESHACK is a team of financial experts, software engineers, and blockchain enthusiasts dedicated to building the future of finance. Our platform is designed to be accessible for beginners while offering powerful features for experienced traders.
                </p>
            </div>
        </div>

        <div class="text-center">
            <h3 class="font-semibold text-lg">Follow Us</h3>
            <div class="flex justify-center gap-4 mt-4">
                <a href="#" class="w-12 h-12 bg-[#1E1F2B] rounded-full flex items-center justify-center hover:bg-gray-700 transition-colors"><i class="ph-bold ph-telegram-logo text-2xl"></i></a>
                <a href="#" class="w-12 h-12 bg-[#1E1F2B] rounded-full flex items-center justify-center hover:bg-gray-700 transition-colors"><i class="ph-bold ph-twitter-logo text-2xl"></i></a>
                <a href="#" class="w-12 h-12 bg-[#1E1F2B] rounded-full flex items-center justify-center hover:bg-gray-700 transition-colors"><i class="ph-bold ph-youtube-logo text-2xl"></i></a>
            </div>
        </div>

         <div class="text-center text-xs text-gray-500 pt-4">
            <p>&copy; <?php echo e(date('Y')); ?> CODESHACK. All Rights Reserved.</p>
            <p>Version 1.0.0</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Projects\cod app\new\tasks website for earning\referral_project\resources\views/pages/about.blade.php ENDPATH**/ ?>