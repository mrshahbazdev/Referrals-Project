<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\ComposerServiceProvider::class,
    App\Providers\SettingServiceProvider::class,
];
