<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\DepositMethod; // Yeh line zaroori hai
use App\Models\InvestmentRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DepositController extends Controller
{
    /**
     * Show the form for creating a new deposit request.
     */
    public function create()
    {
        // Tamam active deposit methods haasil karein
        $depositMethods = DepositMethod::where('is_active', true)->get();
        // Unhein view mein bhejein
        return view('deposits.create', compact('depositMethods'));
    }

    /**
     * Store a newly created deposit request in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'amount' => 'required|numeric|min:1',
            'proof' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        $path = $request->file('proof')->store('proofs', 'public');

        InvestmentRequest::create([
            'user_id' => Auth::id(),
            'amount' => $request->amount,
            'transaction_id_image_url' => $path,
            'status' => 'pending',
        ]);

        return back()->with('success', 'Your deposit request has been submitted and is pending approval.');
    }
}
